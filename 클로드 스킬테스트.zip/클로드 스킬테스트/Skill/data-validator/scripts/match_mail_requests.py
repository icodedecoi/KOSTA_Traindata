#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
data-validator : Gmail 업무요청 ↔ 프로젝트 자료 대조 스크립트

기능
 1. 업무요청(Gmail_업무요청관리표.xlsx 또는 메일 본문 .txt)에서 프로젝트ID 추출
 2. 프로젝트현황과 ID 대조 (없는 ID → 확인 필요, 결과 미검증)
 3. 요청 유형별 검증 항목 결정 (청구·입금 대조 / 계약·누적청구 비교 / 상태 확인)
 4. 실제 Excel에서 금액·상태 조회 (청구·입금은 프로젝트ID별로 각각 먼저 합산)
 5. 요청사항별 결과와 확인 필요 항목 작성 → 메일요청_대조결과.xlsx

메일 금액은 "요청에 기록된 값"이다. 정답으로 쓰지 않고 Excel 실제 합계와 비교만 한다.
원본(Excel·요청표·메일 본문)은 읽기만 하며, 실행 전후 SHA-256을 비교한다.

사용법
  python3 match_mail_requests.py \
      --project-file 01_프로젝트_기본자료.xlsx \
      --transaction-file 02_청구입금_거래자료.xlsx \
      --request-file results/Gmail_업무요청관리표.xlsx   # 또는 --mail-text 메일본문.txt
      --out-dir results [--overwrite]
"""
import argparse
import datetime as dt
import json
import os
import re
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validate_project_amounts import (  # noqa: E402  기존 금액 검증 로직 재사용
    SPECS, Log, aggregate, check_projects, find_header, is_blank, load_table, sha256, write_sheet)
import openpyxl  # noqa: E402

ERR, CHK, UNV = "오류", "확인 필요", "미검증"
TYPE_BILL_PAY = "청구·입금 대조"
TYPE_CONTRACT = "계약·누적청구 비교"
TYPE_STATUS = "프로젝트 상태 확인"

# 업무유형·요청내용 키워드 → 검증 유형 (위에서부터 먼저 맞는 것)
TYPE_RULES = [
    (TYPE_BILL_PAY, ["입금"]),
    (TYPE_CONTRACT, ["계약"]),
    (TYPE_STATUS, ["진행상태", "진행현황", "상태"]),
]
REQ_COLS = ["프로젝트ID", "업무유형", "주요 요청내용"]
AMOUNT_RE = re.compile(r"(계약금액|청구금액|입금금액)\s*([\d,]+(?:\.\d+)?)\s*(억\s*원|만\s*원|원)")
NOT_FULL_RE = re.compile(r"(모두|전체|전액)[^.\n]{0,10}청구(된 상태는 아니|되지 않|하지 않)")
UNIT = {"억원": 100_000_000, "만원": 10_000, "원": 1}


def put(ws, header, rows, status_col=None, widths=None):
    """기존 write_sheet 호출 형식(열 이름 기준)에 맞춰 전달."""
    write_sheet(ws, header, rows, status_cols=(status_col,) if status_col else (),
                widths=dict(zip(header, widths)) if widths else None)


def won(v):
    return "-" if v is None else f"{v:,.0f}원"


def parse_mail_amounts(text):
    """메일 문장 속 금액(텍스트)을 원 단위로 읽는다. 원문 문자열도 함께 남긴다."""
    out = []
    for m in AMOUNT_RE.finditer(text or ""):
        unit = m.group(3).replace(" ", "")
        out.append(dict(kind=m.group(1), raw=m.group(0),
                        value=round(float(m.group(2).replace(",", "")) * UNIT[unit])))
    return out


def decide_type(text):
    for t, kws in TYPE_RULES:
        if any(k in text for k in kws):
            return t
    return None


# ---------------------------------------------------------------- 1. 요청 읽기 + ID 추출
def read_requests(a, id_re):
    reqs, notes = [], []
    if a.request_file:
        wb = openpyxl.load_workbook(a.request_file, data_only=True)
        for ws in wb.worksheets:
            hdr, names = find_header(ws, REQ_COLS)
            if not hdr:
                continue
            idx = {n: i for i, n in enumerate(names) if not is_blank(n)}
            for r, row in enumerate(ws.iter_rows(min_row=hdr + 1, values_only=True), start=hdr + 1):
                get = lambda c: row[idx[c]] if c in idx and idx[c] < len(row) else None  # noqa: E731
                cell_id, body = get("프로젝트ID"), " ".join(str(get(c) or "") for c in ("업무유형", "주요 요청내용"))
                if is_blank(cell_id) and not body.strip():
                    continue
                ids = id_re.findall(str(cell_id or "")) or id_re.findall(body)
                reqs.append(dict(src=f"{ws.title}!{r}행", subject=get("원본 메일 제목") or "", raw_id=cell_id,
                                 ids=ids, work_type=get("업무유형") or "", text=body,
                                 mail_amounts=parse_mail_amounts(str(get("주요 요청내용") or ""))))
            notes.append(f"요청표 '{ws.title}' 시트 {hdr}행을 헤더로 사용")
            break
        else:
            sys.exit(f"요청표에서 필수 열 {REQ_COLS} 을(를) 찾지 못함")
    else:
        text = open(a.mail_text, encoding="utf-8").read()
        subject = a.mail_subject or ""
        # 번호 항목(1. / 2. ...) 단위로 나눈 뒤, 항목 안의 프로젝트ID로 요청을 구분
        blocks = re.split(r"\n\s*(?=\d+\.\s)", "\n" + text)
        for b in blocks:
            # 항목은 번호 줄 + 바로 이어지는 줄까지만 (빈 줄 뒤 맺음말·안내문은 제외)
            b = re.split(r"\n\s*\n", b.strip(), maxsplit=1)[0]
            first = b.splitlines()[0] if b else ""
            if not re.match(r"\d+\.\s", first):
                continue
            ids = id_re.findall(first) or id_re.findall(b)
            if not ids:
                continue
            wt = first.split("—", 1)[1].strip() if "—" in first else ""
            reqs.append(dict(src="메일 본문", subject=subject, raw_id=", ".join(ids), ids=ids, work_type=wt,
                             text=b.strip(), mail_amounts=parse_mail_amounts(b)))
        notes.append("메일 본문 번호 항목 단위로 요청 분리")
    return reqs, notes


# ---------------------------------------------------------------- 3·4·5. 유형별 검증
def verify(req, pid, master, inv_sums, pay_sums, inv_ok, pay_ok):
    p = master.get(pid)
    vtype = decide_type(req["work_type"] + " " + req["text"])
    base = dict(요청출처=req["src"], 원본메일제목=req["subject"], 프로젝트ID=pid,
                프로젝트명=(p or {}).get("프로젝트명", ""), 요청업무유형=req["work_type"],
                검증유형=vtype or CHK, 메일기재값=", ".join(m["raw"] for m in req["mail_amounts"]) or "-")
    checks = []  # (항목, 메일값, Excel값, 판정, 비고)
    todo = []    # 확인 필요 항목

    if p is None:
        base.update(판정=UNV, 결과요약="프로젝트현황에 없는 ID → 금액·상태 조회하지 않음")
        todo.append("프로젝트ID가 프로젝트현황에 없음: 메일 ID 오기 또는 자료 누락 확인")
        return base, checks, todo
    if vtype is None:
        base.update(판정=CHK, 결과요약="요청 문구로 검증 유형을 정하지 못함")
        todo.append("요청 유형을 담당자가 지정해야 함")
        return base, checks, todo

    contract = p.get("_contract")
    bill = inv_sums.get(pid, 0) if inv_ok else None
    pay = pay_sums.get(pid, 0) if pay_ok else None

    def mail_vs(kind, excel_val, label):
        for m in [m for m in req["mail_amounts"] if m["kind"] == kind]:
            if excel_val is None:
                checks.append((f"메일 {kind} vs {label}", won(m["value"]), "-", UNV, "Excel 시트 읽기 실패"))
            else:
                ok = m["value"] == excel_val
                checks.append((f"메일 {kind} vs {label}", won(m["value"]), won(excel_val), "일치" if ok else "불일치",
                               "메일 값은 요청 기록값, Excel 합계 기준으로 판정"))
                if not ok:
                    todo.append(f"메일 기재값 「{m['raw']}」 ↔ {label} {won(excel_val)} 불일치 → 요청자에게 기준 확인")

    if vtype == TYPE_BILL_PAY:
        mail_vs("청구금액", bill, "Excel 청구합계")
        mail_vs("입금금액", pay, "Excel 입금합계")
        if bill is None or pay is None:
            checks.append(("청구합계 − 입금합계", "-", "-", UNV, "청구 또는 입금 시트 읽기 실패"))
        else:
            diff = bill - pay
            checks.append(("청구합계", "-", won(bill), "조회", f"청구 {inv_cnt(pid)}건 합산"))
            checks.append(("입금합계", "-", won(pay), "조회", f"입금 {pay_cnt(pid)}건 합산"))
            checks.append(("청구합계 − 입금합계", "-", won(diff), "일치" if diff == 0 else "차액 확인", ""))
            if diff:
                todo.append(f"청구-입금 차액 {won(diff)}: 차액 원인(미입금·입금 예정·조정 등)은 자료로 미검증")
        summary = f"청구 {won(bill)} / 입금 {won(pay)} / 차액 {won(None if bill is None or pay is None else bill - pay)}"

    elif vtype == TYPE_CONTRACT:
        mail_vs("계약금액", contract, "프로젝트현황 계약금액")
        mail_vs("청구금액", bill, "Excel 누적 청구합계")
        if contract is None or bill is None:
            checks.append(("계약금액 − 누적청구", "-", "-", UNV, "계약금액 또는 청구합계 확인 불가"))
            summary = "계약·청구 비교 미검증"
        else:
            rest = contract - bill
            checks.append(("계약금액", "-", won(contract), "조회", ""))
            checks.append(("누적 청구합계", "-", won(bill), "조회", f"청구 {inv_cnt(pid)}건 합산"))
            checks.append(("계약금액 − 누적청구(미청구액)", "-", won(rest),
                           "차액 있음" if rest > 0 else ("일치" if rest == 0 else "초과 청구"), ""))
            if rest < 0:
                todo.append(f"누적 청구가 계약금액보다 {won(-rest)} 많음 → 계약 변경 여부 확인")
            elif rest > 0:
                todo.append(f"미청구액 {won(rest)}: 향후 청구 계획·일정은 자료에 없어 미검증")
            if NOT_FULL_RE.search(req["text"]):
                checks.append(("메일 진술: 전액 청구 아님", "기재", "미청구 " + won(rest),
                               "일치" if rest > 0 else "불일치", "메일 문장과 Excel 비교"))
            summary = f"계약 {won(contract)} / 누적청구 {won(bill)} / 미청구 {won(rest)}"

    else:  # TYPE_STATUS
        st = p.get("진행상태")
        checks.append(("진행상태", "-", st if not is_blank(st) else "-", "조회" if not is_blank(st) else UNV,
                       "프로젝트현황 진행상태 열"))
        for c in ("시작일", "완료예정일"):
            if c in p:
                checks.append((c, "-", str(p.get(c) or "-"), "조회", "프로젝트현황"))
        if bill is not None and pay is not None:
            checks.append(("참고: 청구합계 / 입금합계", "-", f"{won(bill)} / {won(pay)}", "조회", "상태 판단 근거 아님"))
        checks.append(("월간 진행현황", "-", "-", UNV, "입력 Excel에 월간 진행현황 자료 없음"))
        todo.append("월간 진행현황 요약: 입력 자료에 없음 → 담당자 자료 필요")
        todo.append("보고 필요사항과 확인 필요사항 구분은 담당자 판단 필요(자료로 미검증)")
        summary = f"진행상태 '{st}'" if not is_blank(st) else "진행상태 값 없음"

    verdicts = {c[3] for c in checks}
    base.update(판정="불일치" if "불일치" in verdicts else (UNV if verdicts == {UNV} else
                ("확인 필요" if todo else "일치")), 결과요약=summary)
    return base, checks, todo


def main():
    global inv_cnt, pay_cnt
    ap = argparse.ArgumentParser(description="Gmail 업무요청 ↔ 프로젝트 자료 대조")
    ap.add_argument("--project-file", required=True)
    ap.add_argument("--transaction-file", required=True)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--request-file", help="Gmail_업무요청관리표.xlsx (프로젝트ID·업무유형·주요 요청내용 열 필요)")
    g.add_argument("--mail-text", help="메일 본문 텍스트 파일(UTF-8)")
    ap.add_argument("--mail-subject", default="", help="--mail-text 사용 시 원본 메일 제목")
    ap.add_argument("--id-pattern", default=r"P\d{3}", help="프로젝트ID 정규식 (기본 P숫자3자리)")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--out-name", default="메일요청_대조결과.xlsx")
    ap.add_argument("--overwrite", action="store_true")
    a = ap.parse_args()

    inputs = [a.project_file, a.transaction_file, a.request_file or a.mail_text]
    for f in inputs:
        if not os.path.isfile(f):
            sys.exit(f"입력 파일 없음: {f}")
    os.makedirs(a.out_dir, exist_ok=True)
    out = os.path.join(a.out_dir, a.out_name)
    if os.path.abspath(out) in {os.path.abspath(f) for f in inputs}:
        sys.exit("결과 파일 경로가 원본과 같습니다. 중단합니다.")
    if os.path.exists(out) and not a.overwrite:
        s, e = os.path.splitext(a.out_name)
        out = os.path.join(a.out_dir, f"{s}_{dt.datetime.now():%Y%m%d_%H%M%S}{e}")
    before = {f: sha256(f) for f in inputs}

    # 1. 요청 + ID 추출
    id_re = re.compile(rf"(?<![A-Za-z0-9]){a.id_pattern}(?![0-9])")
    reqs, notes = read_requests(a, id_re)
    mails = sorted({r["subject"] for r in reqs if r["subject"]})

    # 기존 금액 검증 로직으로 Excel 읽기·합산 (청구·입금 각각 프로젝트ID별 먼저 합산)
    log = Log()
    wbs = {"project": openpyxl.load_workbook(a.project_file, data_only=True),
           "transaction": openpyxl.load_workbook(a.transaction_file, data_only=True)}
    paths = {"project": a.project_file, "transaction": a.transaction_file}
    tbls = {n: load_table(wbs[s["source"]], os.path.basename(paths[s["source"]]), s, log) for n, s in SPECS.items()}
    if tbls["project"] is None:
        sys.exit("프로젝트현황 시트를 찾지 못함 → 대조 불가")
    master, dup_ids, _ = check_projects(tbls["project"], log)
    inv = aggregate(tbls["invoice"], master, log) if tbls["invoice"] else ({}, {}, None)
    pay = aggregate(tbls["payment"], master, log) if tbls["payment"] else ({}, {}, None)
    inv_cnt = lambda pid: inv[1].get(pid, 0)  # noqa: E731
    pay_cnt = lambda pid: pay[1].get(pid, 0)  # noqa: E731

    # 2~5
    results, details, todos, extract = [], [], [], []
    for n, r in enumerate(reqs, 1):
        ids = list(dict.fromkeys(r["ids"]))
        extract.append([n, r["src"], r["subject"], str(r["raw_id"] or ""), ", ".join(ids) or "-",
                        ", ".join(i for i in ids if i in master) or "-",
                        ", ".join(i for i in ids if i not in master) or "-"])
        if not ids:
            todos.append([n, "-", CHK, "요청에서 프로젝트ID를 찾지 못함", r["src"]])
            continue
        for pid in ids:
            base, checks, todo = verify(r, pid, master, inv[0], pay[0], bool(tbls["invoice"]), bool(tbls["payment"]))
            if pid in dup_ids:
                todo.append("프로젝트현황에서 ID 중복 → 첫 행 기준으로 조회함")
            results.append([n] + list(base.values()) + ["; ".join(todo) or "-"])
            details += [[n, pid, base["검증유형"]] + list(c) for c in checks]
            todos += [[n, pid, CHK if "미검증" not in t else UNV, t, base["검증유형"]] for t in todo]
    for it in log.issues:  # Excel 자체 오류·확인 필요도 함께 보고
        if it["프로젝트ID"] in {row[3] for row in results}:
            todos.append(["-", it["프로젝트ID"], it["구분"], f"[원본] {it['항목']}: {it['내용']}", it["시트"]])

    after = {f: sha256(f) for f in inputs}
    unchanged = before == after

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "요약"
    summ = [["원본 메일 수", f"{len(mails)}건" if mails else "제목 없음(미확인)"],
            ["원본 메일 제목", " / ".join(mails) or "-"],
            ["추출 업무요청 수", f"{len(reqs)}건 (프로젝트별 구분)"],
            ["대조 프로젝트", ", ".join(dict.fromkeys(r[3] for r in results)) or "-"],
            ["프로젝트현황에 없는 ID", ", ".join(r[3] for r in results if r[-3] == UNV and not r[4]) or "없음"],
            ["판정 분포", ", ".join(f"{k} {sum(1 for r in results if r[-3] == k)}건"
                                   for k in dict.fromkeys(r[-3] for r in results))],
            ["확인 필요 항목 수", f"{len(todos)}건"],
            ["원본 파일 미수정(SHA-256)", "확인" if unchanged else "변경 감지"],
            ["처리 메모", " / ".join(notes)],
            ["검증 범위", "숫자·상태 대조만 수행 · 차액 원인, 정산 완료, 향후 일정은 미검증"]]
    put(ws, ["항목", "내용"], summ, widths=[24, 90])
    put(wb.create_sheet("요청별결과"),
                ["요청No", "요청출처", "원본 메일 제목", "프로젝트ID", "프로젝트명", "요청 업무유형", "검증유형",
                 "메일 기재값", "판정", "결과 요약", "확인 필요 항목"], results,
                status_col="판정", widths=[7, 18, 26, 10, 18, 16, 16, 22, 10, 46, 60])
    put(wb.create_sheet("검증상세"),
                ["요청No", "프로젝트ID", "검증유형", "검증 항목", "메일 값", "Excel 값", "판정", "비고"], details,
                status_col="판정", widths=[7, 10, 16, 30, 16, 24, 10, 36])
    put(wb.create_sheet("확인필요"), ["요청No", "프로젝트ID", "구분", "내용", "관련"], todos,
                status_col="구분", widths=[7, 10, 10, 80, 18])
    put(wb.create_sheet("ID추출"),
                ["요청No", "요청출처", "원본 메일 제목", "원본 ID 값", "추출 ID", "프로젝트현황 있음", "프로젝트현황 없음"],
                extract, widths=[7, 18, 26, 12, 12, 16, 16])
    put(wb.create_sheet("구조검사"), ["파일", "시트", "항목", "결과", "상세"],
                [list(s) for s in log.structure], status_col="결과", widths=[26, 14, 22, 10, 60])
    wb.save(out)
    saved = os.path.isfile(out) and openpyxl.load_workbook(out).sheetnames[0] == "요약"
    print(json.dumps(dict(saved=saved, out=out, originals_unchanged=unchanged, mails=len(mails),
                          requests=len(reqs), results=[dict(No=r[0], ID=r[3], 유형=r[6], 판정=r[-3], 요약=r[-2])
                                                       for r in results], todo_count=len(todos)),
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
