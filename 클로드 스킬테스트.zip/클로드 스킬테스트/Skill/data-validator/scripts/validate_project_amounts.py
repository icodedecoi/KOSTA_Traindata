#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
data-validator : 프로젝트 금액 데이터 검증 스크립트

기능
 1. 프로젝트 Excel 파일 읽기 (원본은 저장하지 않음 → 미수정, 실행 전후 SHA-256 비교)
 2. 시트·열 구조 검사 (제목 행, 다중 헤더, 병합 셀, 빈 행, 숨김 시트/행)
 3. 프로젝트ID 누락·중복 확인
 4. 청구금액 프로젝트별 합산
 5. 입금금액 프로젝트별 합산
 6. 프로젝트별 청구·입금 차액 계산 (청구·입금을 각각 먼저 합산한 뒤 프로젝트현황에 연결)
 7. 원본 합계와 결과 비교
 8. 오류·확인 필요·미검증 항목 분리
 9. 정산검증_결과표.xlsx 생성

사용법
  python3 validate_project_amounts.py \
      --project-file 01_프로젝트_기본자료.xlsx \
      --transaction-file 02_청구입금_거래자료.xlsx \
      --out-dir results [--overwrite]
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import re
import sys
from collections import OrderedDict

try:
    import openpyxl
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("openpyxl 이 필요합니다: pip install openpyxl")

SPECS = OrderedDict([
    ("project", dict(label="프로젝트현황", source="project", preferred="프로젝트현황",
                     required=["프로젝트ID", "프로젝트명", "담당부서", "계약금액(원)"],
                     key="프로젝트ID", amount="계약금액(원)", date=None)),
    ("invoice", dict(label="청구내역", source="transaction", preferred="청구내역",
                     required=["청구ID", "프로젝트ID", "청구일", "청구금액(원)"],
                     key="청구ID", amount="청구금액(원)", date="청구일")),
    ("payment", dict(label="입금내역", source="transaction", preferred="입금내역",
                     required=["입금ID", "프로젝트ID", "입금일", "입금금액(원)"],
                     key="입금ID", amount="입금금액(원)", date="입금일")),
])
HEADER_SCAN_ROWS = 10
SCOPE_TEXT = "숫자 대조만 수행 · 차액 원인·정산 완료 여부는 미검증"
ERR, CHK, UNV = "오류", "확인 필요", "미검증"
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


def norm(v):
    return v.strip() if isinstance(v, str) else v


def is_blank(v):
    return v is None or (isinstance(v, str) and v.strip() == "")


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def parse_amount(v):
    """숫자 셀만 금액으로 인정. 텍스트 숫자는 임의 변환하지 않고 제외."""
    if is_blank(v):
        return None, "금액 비어 있음"
    if is_num(v):
        return v, None
    return None, f"금액이 숫자 셀이 아님({str(v)!r})"


def check_date(v):
    if isinstance(v, (dt.date, dt.datetime)):
        return None
    if is_blank(v):
        return "날짜 비어 있음"
    s = str(v).strip()
    if not DATE_RE.match(s):
        return f"날짜 형식이 YYYY-MM-DD 아님({v!r})"
    try:
        dt.date.fromisoformat(s)
    except ValueError:
        return f"존재하지 않는 날짜({v!r})"
    return None


class Log:
    def __init__(self):
        self.structure, self.issues = [], []

    def s(self, f, sh, item, result, detail=""):
        self.structure.append((f, sh, item, result, detail))

    def i(self, level, f, sh, row, rid, pid, item, detail, handling):
        self.issues.append(dict(구분=level, 파일=f, 시트=sh, 행=row, 거래ID=rid,
                                프로젝트ID=pid, 항목=item, 내용=detail, 처리=handling))


# ---------------------------------------------------------------- 1·2. 읽기 + 구조 검사
def find_header(ws, required):
    """첫 행을 자동으로 헤더로 가정하지 않고, 앞쪽 행에서 필수 열을 모두 가진 행을 찾는다."""
    for r_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=HEADER_SCAN_ROWS, values_only=True), start=1):
        names = [norm(c) for c in row]
        if all(req in names for req in required):
            return r_idx, names
    return None, None


def load_table(wb, fname, spec, log):
    label = spec["label"]
    cands = ([wb[spec["preferred"]]] if spec["preferred"] in wb.sheetnames else []) + \
            [ws for ws in wb.worksheets if ws.title != spec["preferred"]]
    for ws in cands:
        hdr_row, names = find_header(ws, spec["required"])
        if hdr_row:
            break
    else:
        log.s(fname, "-", f"{label} 시트 탐색", ERR,
              f"필수 열 {spec['required']} 을(를) 모두 가진 시트 없음 → {label} 관련 결과 미검증")
        return None

    sh = ws.title
    log.s(fname, sh, f"{label} 시트 탐색", "정상" if sh == spec["preferred"] else CHK,
          f"'{sh}' 시트 사용" + ("" if sh == spec["preferred"] else f" (기대 시트명 '{spec['preferred']}' 없음, 열 구성으로 선택)"))
    log.s(fname, sh, "시트 표시 상태", "정상" if ws.sheet_state == "visible" else CHK, ws.sheet_state)
    log.s(fname, sh, "사용 범위", "정보", f"{ws.dimensions} (최대 {ws.max_row}행 × {ws.max_column}열)")
    log.s(fname, sh, "헤더 행 위치", "정상" if hdr_row == 1 else CHK, f"{hdr_row}행")
    above = [r for r in range(1, hdr_row) if any(not is_blank(c.value) for c in ws[r])]
    log.s(fname, sh, "헤더 위 제목·추가 행", "없음" if not above else CHK,
          "" if not above else f"{above}행에 값 있음(제목 행 또는 다중 헤더 가능성)")
    merged = [str(m) for m in ws.merged_cells.ranges]
    log.s(fname, sh, "병합 셀", "없음" if not merged else CHK, ", ".join(merged))

    cols = [n for n in names if not is_blank(n)]
    spaced = [c.value for c in ws[hdr_row] if isinstance(c.value, str) and c.value != c.value.strip()]
    dups = sorted({str(n) for n in cols if cols.count(n) > 1})
    log.s(fname, sh, "열 목록", "정보", " | ".join(str(c) for c in cols))
    log.s(fname, sh, "필수 열", "정상", ", ".join(spec["required"]))
    log.s(fname, sh, "중복 열 이름", "없음" if not dups else ERR, ", ".join(dups))
    log.s(fname, sh, "열 이름 앞뒤 공백", "없음" if not spaced else CHK, ", ".join(repr(s) for s in spaced))

    idx = {n: i for i, n in enumerate(names) if not is_blank(n) and str(n) not in dups}
    noname = set()
    rows, blanks, hidden = [], [], []
    for r_idx, row in enumerate(ws.iter_rows(min_row=hdr_row + 1, values_only=True), start=hdr_row + 1):
        if all(is_blank(v) for v in row):
            blanks.append(r_idx)
            continue
        for i, v in enumerate(row):
            if not is_blank(v) and (i >= len(names) or is_blank(names[i])):
                noname.add(get_column_letter(i + 1))
        if ws.row_dimensions[r_idx].hidden:
            hidden.append(r_idx)
        rec = {n: (row[i] if i < len(row) else None) for n, i in idx.items()}
        rec["_row"] = r_idx
        rows.append(rec)
    last = rows[-1]["_row"] if rows else hdr_row
    inner_blank = [b for b in blanks if b < last]
    log.s(fname, sh, "이름 없는 열에 값", "없음" if not noname else CHK, ", ".join(sorted(noname)))
    log.s(fname, sh, "데이터 행 수", "정보", f"{len(rows)}행 (헤더·빈 행 제외)")
    log.s(fname, sh, "중간 빈 행", "없음" if not inner_blank else CHK, ", ".join(map(str, inner_blank)))
    log.s(fname, sh, "숨김 행", "없음" if not hidden else CHK, ", ".join(map(str, hidden)))
    for b in inner_blank:
        log.i(CHK, fname, sh, b, "", "", "빈 행", "데이터 중간에 빈 행", "값 없음, 집계 영향 없음")
    for h in hidden:
        log.i(CHK, fname, sh, h, "", "", "숨김 행", "숨겨진 데이터 행", "집계에 포함, 원본 확인 필요")
    return dict(file=fname, sheet=sh, rows=rows, spec=spec)


# ---------------------------------------------------------------- 3. 프로젝트ID 누락·중복
def check_projects(tbl, log):
    f, sh = tbl["file"], tbl["sheet"]
    master, dup_ids, excluded = OrderedDict(), set(), []
    for r in tbl["rows"]:
        raw = r["프로젝트ID"]
        amt, prob = parse_amount(r["계약금액(원)"])
        if is_blank(raw):
            log.i(ERR, f, sh, r["_row"], "", "", "프로젝트ID 누락", "프로젝트ID가 비어 있음", "연결 대상에서 제외")
            excluded.append(amt)
            continue
        pid = str(raw).strip()
        if isinstance(raw, str) and raw != pid:
            log.i(CHK, f, sh, r["_row"], "", pid, "프로젝트ID 공백", f"앞뒤 공백 포함({raw!r})", "공백 제거한 값으로 연결(원본 미수정)")
        if pid in master:
            dup_ids.add(pid)
            log.i(ERR, f, sh, r["_row"], "", pid, "프로젝트ID 중복",
                  f"{master[pid]['_row']}행과 같은 ID", "첫 행만 사용, 이 행은 제외")
            excluded.append(amt)
            continue
        if prob:
            log.i(CHK, f, sh, r["_row"], "", pid, "계약금액", prob, "계약금액 관련 계산 미검증")
        master[pid] = dict(r, _pid=pid, _contract=amt)
    return master, dup_ids, excluded


# ---------------------------------------------------------------- 4·5. 거래 합산(연결 전)
def aggregate(tbl, master, log):
    spec, f, sh = tbl["spec"], tbl["file"], tbl["sheet"]
    key, acol, dcol = spec["key"], spec["amount"], spec["date"]
    sums, counts, seen_ids, seen_rows = OrderedDict(), OrderedDict(), {}, {}
    st = dict(rows=len(tbl["rows"]), numeric_total=0, used_rows=0, used_total=0, excluded=[])

    for r in tbl["rows"]:
        rn = r["_row"]
        rid = "" if is_blank(r[key]) else str(r[key]).strip()
        raw_pid = r["프로젝트ID"]
        pid = "" if is_blank(raw_pid) else str(raw_pid).strip()
        amt, aprob = parse_amount(r[acol])
        if amt is not None:
            st["numeric_total"] += amt

        def exclude(level, item, detail):
            log.i(level, f, sh, rn, rid, pid, item, detail, "합산에서 제외")
            st["excluded"].append(dict(row=rn, rid=rid, pid=pid, amount=amt, reason=item))

        sig = tuple((k, str(v)) for k, v in r.items() if k != "_row")
        if sig in seen_rows:
            exclude(CHK, "중복 거래 행", f"{seen_rows[sig]}행과 모든 값이 같음")
            continue
        seen_rows[sig] = rn
        if not rid:
            log.i(CHK, f, sh, rn, "", pid, f"{key} 누락", f"{key}가 비어 있음", "합산은 진행, 원본 확인 필요")
        elif rid in seen_ids:
            exclude(CHK, f"{key} 중복", f"{seen_ids[rid]}행과 같은 {key}, 다른 값 있음")
            continue
        else:
            seen_ids[rid] = rn
        if aprob:
            exclude(ERR, "금액 오류", aprob)
            continue
        if not pid:
            exclude(ERR, "프로젝트ID 누락", "프로젝트ID가 비어 있음")
            continue
        if isinstance(raw_pid, str) and raw_pid != pid:
            log.i(CHK, f, sh, rn, rid, pid, "프로젝트ID 공백", f"앞뒤 공백 포함({raw_pid!r})", "공백 제거한 값으로 합산(원본 미수정)")
        if pid not in master:
            exclude(CHK, "프로젝트현황에 없는 ID", f"{pid} 가 프로젝트현황에 없음")
            continue
        if amt <= 0:
            log.i(CHK, f, sh, rn, rid, pid, "금액 0 이하", f"금액 {amt:,}", "합산에 포함, 원본 확인 필요")
        dprob = check_date(r.get(dcol)) if dcol else None
        if dprob:
            log.i(CHK, f, sh, rn, rid, pid, f"{dcol} 형식", dprob, "합산에 포함, 날짜 미검증")
        sums[pid] = sums.get(pid, 0) + amt
        counts[pid] = counts.get(pid, 0) + 1
        st["used_rows"] += 1
        st["used_total"] += amt
    return sums, counts, st


# ---------------------------------------------------------------- 6. 연결 + 차액
def build_result(master, dup_ids, inv, pay, log):
    out = []
    for pid, p in master.items():
        c = p["_contract"]
        isum = inv[0].get(pid, 0) if inv else None
        psum = pay[0].get(pid, 0) if pay else None
        ic = inv[1].get(pid, 0) if inv else None
        pc = pay[1].get(pid, 0) if pay else None
        notes = []
        if c is None:
            notes.append("계약금액이 숫자가 아님")
        cmi = UNV if (c is None or isum is None) else c - isum
        imp = UNV if (isum is None or psum is None) else isum - psum

        if pid in dup_ids:
            status = CHK
            notes.append("프로젝트ID 중복(첫 행 기준)")
        elif imp == UNV:
            status = UNV
            notes.append("청구 또는 입금 시트를 읽지 못함")
        elif ic == 0 and pc == 0:
            status = "기록 없음"
            notes.append("청구·입금 기록 없음(계산 시 0)")
            log.i(CHK, "결과", "정산검증", "", "", pid, "거래 기록 없음", "청구·입금 기록이 모두 없음", "0으로 계산, 원본 확인 필요")
        elif imp == 0:
            status = "일치"
        else:
            status = "차액 확인"
        if is_num(imp) and imp < 0:
            notes.append("입금합계가 청구합계보다 큼")
            log.i(CHK, "결과", "정산검증", "", "", pid, "입금 초과", f"입금이 청구보다 {-imp:,}원 많음", "원본 확인 필요")
        if is_num(cmi) and cmi < 0:
            notes.append("청구합계가 계약금액보다 큼")
            log.i(CHK, "결과", "정산검증", "", "", pid, "청구 초과", f"청구가 계약보다 {-cmi:,}원 많음", "원본 확인 필요")
        if ic == 0 and pc:
            notes.append("청구 없이 입금만 있음")

        out.append(OrderedDict([
            ("프로젝트ID", pid), ("프로젝트명", p.get("프로젝트명")), ("담당부서", p.get("담당부서")),
            ("진행상태", p.get("진행상태", UNV)),
            ("계약금액(원)", c if c is not None else UNV),
            ("청구건수", UNV if ic is None else ic), ("청구금액합계(원)", UNV if isum is None else isum),
            ("입금건수", UNV if pc is None else pc), ("입금금액합계(원)", UNV if psum is None else psum),
            ("계약-청구차액(원)", cmi), ("청구-입금차액(원)", imp),
            ("숫자대조상태", status), ("비고", "; ".join(notes)), ("검증범위", SCOPE_TEXT),
        ]))
    return out


# ---------------------------------------------------------------- 7. 원본 합계 대조
def reconcile(proj_tbl, proj_excluded, result, inv_st, pay_st):
    ok = lambda a, b: "일치" if a == b else "불일치"
    rows = []
    raw_total = sum(r["계약금액(원)"] for r in proj_tbl["rows"] if is_num(r["계약금액(원)"]))
    res_total = sum(r["계약금액(원)"] for r in result if is_num(r["계약금액(원)"]))
    exc = sum(a for a in proj_excluded if is_num(a))
    rows.append(["계약금액", len(proj_tbl["rows"]), len(result), raw_total, res_total, exc, res_total + exc,
                 ok(raw_total, res_total + exc),
                 f"제외 = ID 누락·중복 행 {len(proj_excluded)}건; 행 대조 "
                 + ok(len(proj_tbl["rows"]), len(result) + len(proj_excluded))])
    for name, st, col in (("청구금액", inv_st, "청구금액합계(원)"), ("입금금액", pay_st, "입금금액합계(원)")):
        if st is None:
            rows.append([name, UNV, UNV, UNV, UNV, UNV, UNV, UNV, "시트를 읽지 못함"])
            continue
        res = sum(r[col] for r in result if is_num(r[col]))
        exc = sum(e["amount"] for e in st["excluded"] if is_num(e["amount"]))
        row_ok = ok(st["rows"], st["used_rows"] + len(st["excluded"]))
        amt_ok = ok(st["numeric_total"], res + exc)
        rows.append([name, st["rows"], st["used_rows"], st["numeric_total"], res, exc, res + exc,
                     "일치" if (row_ok == amt_ok == "일치") else "불일치",
                     f"반영 행 {st['used_rows']} + 제외 행 {len(st['excluded'])} = 원본 행 {st['rows']} ({row_ok}); "
                     f"원본 합계는 숫자 셀만 합산"])
    return rows


# ---------------------------------------------------------------- 9. Excel 출력
HFILL = PatternFill("solid", fgColor="1F4E78")
HFONT = Font(bold=True, color="FFFFFF")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
FILLS = {"일치": "E2EFDA", "정상": "E2EFDA", "없음": "E2EFDA", "차액 확인": "FFF2CC", CHK: "FFF2CC",
         ERR: "F8CBAD", "불일치": "F8CBAD", UNV: "D9D9D9", "기록 없음": "DDEBF7"}


def write_sheet(ws, header, rows, money_cols=(), status_cols=(), widths=None):
    ws.append(header)
    for c in ws[1]:
        c.fill, c.font, c.border = HFILL, HFONT, BORDER
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    if not rows:
        ws.append(["해당 항목 없음"] + [""] * (len(header) - 1))
    for r in rows:
        ws.append(list(r))
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.border = BORDER
            c.alignment = Alignment(vertical="center", wrap_text=True)
            h = header[c.column - 1]
            if h in money_cols and is_num(c.value):
                c.number_format = "#,##0"
            if h in status_cols and c.value in FILLS:
                c.fill = PatternFill("solid", fgColor=FILLS[c.value])
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = ws.dimensions
    for i, h in enumerate(header, start=1):
        w = (widths or {}).get(h)
        if w is None:
            vals = [len(str(h))] + [len(str(r[i - 1])) for r in rows if r[i - 1] is not None]
            w = min(max(vals) * 1.6 + 2, 60)
        ws.column_dimensions[get_column_letter(i)].width = w


def main():
    ap = argparse.ArgumentParser(description="프로젝트 금액 데이터 검증")
    ap.add_argument("--project-file", required=True)
    ap.add_argument("--transaction-file", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--out-name", default="정산검증_결과표.xlsx")
    ap.add_argument("--overwrite", action="store_true", help="같은 이름 결과 파일이 있으면 덮어씀")
    a = ap.parse_args()

    inputs = {"project": a.project_file, "transaction": a.transaction_file}
    for p in inputs.values():
        if not os.path.isfile(p):
            sys.exit(f"입력 파일 없음: {p}")
    os.makedirs(a.out_dir, exist_ok=True)
    out_path = os.path.join(a.out_dir, a.out_name)
    if os.path.abspath(out_path) in {os.path.abspath(p) for p in inputs.values()}:
        sys.exit("결과 파일 경로가 원본 파일과 같습니다. 중단합니다.")
    if os.path.exists(out_path) and not a.overwrite:
        stem, ext = os.path.splitext(a.out_name)
        out_path = os.path.join(a.out_dir, f"{stem}_{dt.datetime.now():%Y%m%d_%H%M%S}{ext}")

    before = {p: sha256(p) for p in inputs.values()}
    log = Log()

    # 1. 읽기 (병합 셀 확인을 위해 일반 모드. 원본 워크북은 저장하지 않음)
    wbs = {}
    for k, p in inputs.items():
        wbs[k] = openpyxl.load_workbook(p, data_only=True)
        log.s(os.path.basename(p), "-", "파일 열기", "정상",
              "시트: " + ", ".join(f"{ws.title}({ws.sheet_state})" for ws in wbs[k].worksheets))
    # 2
    tbls = {n: load_table(wbs[s["source"]], os.path.basename(inputs[s["source"]]), s, log) for n, s in SPECS.items()}
    if tbls["project"] is None:
        print(json.dumps(dict(saved=False, reason="프로젝트현황 시트를 찾지 못함", structure=log.structure),
                         ensure_ascii=False, indent=2))
        sys.exit(2)
    # 3
    master, dup_ids, proj_exc = check_projects(tbls["project"], log)
    # 4·5 각각 먼저 합산
    inv = aggregate(tbls["invoice"], master, log) if tbls["invoice"] else None
    pay = aggregate(tbls["payment"], master, log) if tbls["payment"] else None
    # 6 프로젝트현황에 연결
    result = build_result(master, dup_ids, inv, pay, log)
    # 7
    recon = reconcile(tbls["project"], proj_exc, result, inv[2] if inv else None, pay[2] if pay else None)

    after = {p: sha256(p) for p in inputs.values()}
    unchanged = before == after

    num = lambda col: sum(r[col] for r in result if is_num(r[col]))
    n_err = sum(1 for x in log.issues if x["구분"] == ERR)
    n_chk = sum(1 for x in log.issues if x["구분"] == CHK)
    diff_rows = [r for r in result if r["숫자대조상태"] == "차액 확인"]
    diff_total = sum(r["청구-입금차액(원)"] for r in diff_rows)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "요약"
    summary = [
        ("실행 일시", f"{dt.datetime.now():%Y-%m-%d %H:%M:%S}"),
        ("프로젝트 파일 / 시트", f"{os.path.basename(a.project_file)} / {tbls['project']['sheet']}"),
        ("거래 파일 / 시트", f"{os.path.basename(a.transaction_file)} / "
                         f"{tbls['invoice']['sheet'] if tbls['invoice'] else UNV}, "
                         f"{tbls['payment']['sheet'] if tbls['payment'] else UNV}"),
        ("집계 방식", "청구내역·입금내역을 프로젝트ID별로 각각 먼저 합산 → 프로젝트현황에 연결(거래 행끼리 직접 연결하지 않음)"),
        ("프로젝트 수(고유 ID)", len(result)),
        ("계약금액 합계(원)", num("계약금액(원)")),
        ("청구금액 합계(원)", num("청구금액합계(원)")),
        ("입금금액 합계(원)", num("입금금액합계(원)")),
        ("청구-입금 차액 합계(원)", num("청구금액합계(원)") - num("입금금액합계(원)")),
        ("차액 확인 프로젝트", f"{len(diff_rows)}건 ({', '.join(r['프로젝트ID'] for r in diff_rows)})" if diff_rows else "0건"),
        ("차액 확인 프로젝트 차액 합계(원)", diff_total),
        ("원본 합계 대조", " / ".join(f"{r[0]}: {r[7]}" for r in recon)),
        ("오류 건수", n_err),
        ("확인 필요 건수", n_chk),
        ("원본 파일 수정 여부", "수정 없음(실행 전후 SHA-256 동일)" if unchanged else "경고: 실행 중 원본 해시가 바뀜"),
        ("미검증 범위", "차액 발생 원인, 정산 완료·미수금·연체 여부, 금액 자체의 정확성, 원본에 없는 거래"),
    ]
    write_sheet(ws, ["항목", "값"], summary, widths={"항목": 32, "값": 95})
    for row in ws.iter_rows(min_row=2):
        if is_num(row[1].value) and "(원)" in str(row[0].value):
            row[1].number_format = "#,##0"

    hdr = list(result[0].keys())
    money = [h for h in hdr if "(원)" in h]
    write_sheet(wb.create_sheet("정산검증"), hdr, [list(r.values()) for r in result],
                money_cols=money, status_cols=("숫자대조상태",) + tuple(money), widths={"비고": 40, "검증범위": 42})
    write_sheet(wb.create_sheet("원본합계대조"),
                ["구분", "원본 데이터 행", "집계 반영 행", "원본 합계(원)", "결과표 합계(원)", "집계 제외 금액(원)",
                 "결과+제외(원)", "대조 결과", "설명"], recon,
                money_cols=("원본 합계(원)", "결과표 합계(원)", "집계 제외 금액(원)", "결과+제외(원)"),
                status_cols=("대조 결과",), widths={"설명": 70})
    ih = ["구분", "파일", "시트", "행", "거래ID", "프로젝트ID", "항목", "내용", "처리"]
    srt = sorted(log.issues, key=lambda x: (x["파일"], x["시트"], str(x["행"]).zfill(6)))
    for name, lv in (("오류", ERR), ("확인필요", CHK)):
        write_sheet(wb.create_sheet(name), ih, [[x[k] for k in ih] for x in srt if x["구분"] == lv],
                    status_cols=("구분",), widths={"내용": 45, "처리": 32})
    write_sheet(wb.create_sheet("구조검사"), ["파일", "시트", "검사 항목", "결과", "상세"], log.structure,
                status_cols=("결과",), widths={"상세": 75})
    unv = [
        ("차액 발생 원인", UNV, "원본에 원인 정보 없음"),
        ("정산 완료 여부", UNV, "청구-입금 차액 0은 숫자 일치일 뿐 정산 완료를 뜻하지 않음"),
        ("미수금·연체 여부", UNV, "약정 입금일·계약 조건 정보 없음"),
        ("계약금액·거래금액의 정확성", UNV, "외부 증빙과 대조하지 않음"),
        ("원본에 없는 거래", UNV, "누락 거래는 원본만으로 확인 불가"),
    ]
    write_sheet(wb.create_sheet("미검증항목"), ["항목", "상태", "사유"], unv, status_cols=("상태",),
                widths={"항목": 28, "사유": 70})
    wb.save(out_path)

    chk = openpyxl.load_workbook(out_path, read_only=True)
    sheets = chk.sheetnames
    chk.close()
    print(json.dumps(dict(
        saved=os.path.isfile(out_path), output=out_path, sheets=sheets, projects=len(result),
        contract_total=num("계약금액(원)"), invoice_total=num("청구금액합계(원)"),
        payment_total=num("입금금액합계(원)"), diff_projects=[r["프로젝트ID"] for r in diff_rows],
        diff_total=diff_total, reconcile={r[0]: r[7] for r in recon}, errors=n_err, checks=n_chk,
        originals_unchanged=unchanged), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
