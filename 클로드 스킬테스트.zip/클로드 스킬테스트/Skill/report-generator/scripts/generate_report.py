#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
report-generator : 정산검증_결과표.xlsx(data-validator 출력) → 부서장용 1페이지 보고서(DOCX)

기능
 1. 검증 결과표 읽기 (필수 시트·열 확인, 원본 거래자료는 읽지 않음)
 2. 전체 금액 요약 (요약 시트 값 그대로 사용)
 3. 청구·입금 차액 표시 (정산검증 시트에서 숫자대조상태='차액 확인' 행)
 4. 오류 및 확인 필요 항목 정리
 5. 담당자 검토사항 작성 (원인 추정 없이 확인 행동만 기술)
 6. 1페이지 한국어 보고서 작성 (DOCX)
 7. 검증표와 보고서 수치 일치 확인 (작성 전 내부 일관성 + 작성 후 보고서 본문 숫자 대조 + 쪽수 확인)

사용법
  python3 generate_report.py --input results/정산검증_결과표.xlsx --out-dir results [--overwrite]
"""
import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

try:
    import openpyxl
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor
except ImportError as e:
    sys.exit(f"필요 패키지 없음({e}). pip install openpyxl python-docx")

REQUIRED = {
    "요약": ["항목", "값"],
    "정산검증": ["프로젝트ID", "프로젝트명", "담당부서", "계약금액(원)", "청구금액합계(원)",
               "입금금액합계(원)", "청구-입금차액(원)", "숫자대조상태"],
    "원본합계대조": ["구분", "대조 결과"],
    "오류": ["구분", "파일", "시트", "행", "거래ID", "프로젝트ID", "항목", "내용", "처리"],
    "확인필요": ["구분", "파일", "시트", "행", "거래ID", "프로젝트ID", "항목", "내용", "처리"],
    "미검증항목": ["항목", "상태", "사유"],
}
SUMMARY_KEYS = ["실행 일시", "프로젝트 수(고유 ID)", "계약금액 합계(원)", "청구금액 합계(원)",
                "입금금액 합계(원)", "청구-입금 차액 합계(원)", "차액 확인 프로젝트",
                "차액 확인 프로젝트 차액 합계(원)", "원본 합계 대조", "오류 건수", "확인 필요 건수"]
MAX_DIFF_ROWS = 8
MAX_ISSUE_ROWS = 6
MAX_REVIEW_LINES = 7


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def won(v):
    return f"{v:,.0f}" if is_num(v) else str(v)


# ---------------------------------------------------------------- 1. 읽기
def read_sheet(wb, name):
    rows = list(wb[name].iter_rows(values_only=True))
    hdr = [h.strip() if isinstance(h, str) else h for h in rows[0]]
    data = [dict(zip(hdr, r)) for r in rows[1:] if any(v not in (None, "") for v in r)]
    return hdr, data


def load(path):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    problems = []
    for s, cols in REQUIRED.items():
        if s not in wb.sheetnames:
            problems.append(f"시트 없음: {s}")
            continue
        hdr = [c.value for c in next(wb[s].iter_rows(min_row=1, max_row=1))]
        miss = [c for c in cols if c not in hdr]
        if miss:
            problems.append(f"{s} 시트 열 없음: {miss}")
    if problems:
        return None, problems
    d = {s: read_sheet(wb, s)[1] for s in REQUIRED}
    summ = {r["항목"]: r["값"] for r in d["요약"]}
    miss = [k for k in SUMMARY_KEYS if k not in summ]
    if miss:
        return None, [f"요약 시트 항목 없음: {miss}"]
    d["summary"] = summ
    # '해당 항목 없음' 자리표시 행 제거
    for s in ("오류", "확인필요"):
        d[s] = [r for r in d[s] if r.get("구분") in ("오류", "확인 필요")]
    # 허용 숫자(결과표에 실제 있는 값)
    allowed = set()
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            for v in row:
                if is_num(v):
                    allowed.add(int(round(v)))
                elif isinstance(v, str):
                    for m in re.findall(r"\d[\d,]*", v):
                        allowed.add(int(m.replace(",", "")))
    d["allowed"] = allowed
    wb.close()
    return d, []


# ---------------------------------------------------------------- 7-1. 작성 전 내부 일관성
def consistency(d):
    s, rows = d["summary"], d["정산검증"]
    checks = []

    def add(name, a, b):
        checks.append(dict(항목=name, 요약=a, 정산검증=b, 결과="일치" if a == b else "불일치"))

    col_sum = lambda c: sum(r[c] for r in rows if is_num(r[c]))
    diff_rows = [r for r in rows if r["숫자대조상태"] == "차액 확인"]
    add("프로젝트 수", s["프로젝트 수(고유 ID)"], len(rows))
    add("계약금액 합계", s["계약금액 합계(원)"], col_sum("계약금액(원)"))
    add("청구금액 합계", s["청구금액 합계(원)"], col_sum("청구금액합계(원)"))
    add("입금금액 합계", s["입금금액 합계(원)"], col_sum("입금금액합계(원)"))
    add("청구-입금 차액 합계", s["청구-입금 차액 합계(원)"], col_sum("청구금액합계(원)") - col_sum("입금금액합계(원)"))
    add("차액 확인 프로젝트 차액 합계", s["차액 확인 프로젝트 차액 합계(원)"],
        sum(r["청구-입금차액(원)"] for r in diff_rows if is_num(r["청구-입금차액(원)"])))
    m = re.match(r"\s*(\d+)\s*건", str(s["차액 확인 프로젝트"]))
    add("차액 확인 프로젝트 수", int(m.group(1)) if m else s["차액 확인 프로젝트"], len(diff_rows))
    ids = re.findall(r"[A-Za-z]+\d+", str(s["차액 확인 프로젝트"]))
    add("차액 확인 프로젝트 목록", ids, [r["프로젝트ID"] for r in diff_rows])
    add("오류 건수", s["오류 건수"], len(d["오류"]))
    add("확인 필요 건수", s["확인 필요 건수"], len(d["확인필요"]))
    bad = [r["구분"] for r in d["원본합계대조"] if r["대조 결과"] != "일치"]
    checks.append(dict(항목="원본합계대조 시트", 요약="모두 일치", 정산검증=("모두 일치" if not bad else f"불일치: {bad}"),
                       결과="일치" if not bad else "불일치"))
    return checks, diff_rows


# ---------------------------------------------------------------- 5. 검토사항
def review_items(diff_rows, d):
    items = []
    for r in diff_rows:
        items.append(f"[{r['담당부서']}] {r['프로젝트ID']} {r['프로젝트명']}: 청구-입금 차액 "
                     f"{won(r['청구-입금차액(원)'])}원 — 해당 청구·입금 증빙을 대조하고 차이 사유를 확인")
    for r in d["오류"]:
        items.append(f"[원본 관리자] {r['시트']} {r['행']}행 {r['항목']}: {r['내용']} — 원본 정정 여부 판단")
    dept = {r["프로젝트ID"]: r["담당부서"] for r in d["정산검증"]}
    for r in d["확인필요"]:
        tgt = r["프로젝트ID"] or f"{r['시트']} {r['행']}행"
        items.append(f"[{dept.get(r['프로젝트ID'], '원본 관리자')}] {tgt} {r['항목']}: {r['내용']} — 원본 기록 확인")
    return items


# ---------------------------------------------------------------- 6. DOCX
def set_font(run, size=None, bold=None, color=None):
    run.font.name = "맑은 고딕"
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "맑은 고딕")
    if size:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def para(doc, text, size=9.5, bold=False, color=None, align=None, after=2, before=0):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.line_spacing = 1.1
    if align:
        p.alignment = align
    set_font(p.add_run(text), size, bold, color)
    return p


def heading(doc, text):
    return para(doc, text, size=11, bold=True, color="1F4E78", before=5, after=2)


def shade(cell, hexcolor):
    tcPr = cell._element.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear")
    sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), hexcolor)
    tcPr.append(sh)


def table(doc, header, rows, widths, num_cols=()):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        set_font(c.paragraphs[0].add_run(h), 8.5, True, "FFFFFF")
        c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        shade(c, "1F4E78")
    for r in rows:
        cells = t.add_row().cells
        for i, v in enumerate(r):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            set_font(p.add_run(str(v)), 8.5)
            if i in num_cols:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    t.autofit = False
    grid = t._tbl.tblGrid
    for i, gc in enumerate(grid.findall(qn("w:gridCol"))):
        gc.set(qn("w:w"), str(int(widths[i] * 567)))
    for row in t.rows:
        for i, w in enumerate(widths):
            row.cells[i].width = Cm(w)
            for p in row.cells[i].paragraphs:
                p.paragraph_format.space_after = Pt(0)
    return t


def build_doc(d, diff_rows, reviews, src_name):
    s = d["summary"]
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    sec.top_margin = sec.bottom_margin = Cm(1.6)
    sec.left_margin = sec.right_margin = Cm(1.8)

    para(doc, "프로젝트 청구·입금 숫자 대조 결과 보고", size=15, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, after=1)
    para(doc, f"보고일 {dt.date.today():%Y-%m-%d} · 검증 실행 {s['실행 일시']} · 근거 자료 {src_name}",
         size=8.5, color="595959", align=WD_ALIGN_PARAGRAPH.CENTER, after=4)

    n_diff = len(diff_rows)
    heading(doc, "1. 결론")
    para(doc, f"• 프로젝트 {s['프로젝트 수(고유 ID)']}건 중 {n_diff}건에서 청구금액이 입금금액과 달라 확인이 필요합니다"
              f"(차액 합계 {won(s['차액 확인 프로젝트 차액 합계(원)'])}원)." if n_diff else
              f"• 프로젝트 {s['프로젝트 수(고유 ID)']}건 모두 청구·입금 숫자가 일치합니다.")
    para(doc, f"• 원본 합계 대조 결과: {s['원본 합계 대조']}.")
    para(doc, f"• 오류 {s['오류 건수']}건, 확인 필요 {s['확인 필요 건수']}건. 차액의 원인과 정산 완료 여부는 미검증입니다.")

    heading(doc, "2. 전체 금액 요약")
    table(doc, ["계약금액 합계", "청구금액 합계", "입금금액 합계", "청구-입금 차액 합계"],
          [[won(s["계약금액 합계(원)"]) + "원", won(s["청구금액 합계(원)"]) + "원",
            won(s["입금금액 합계(원)"]) + "원", won(s["청구-입금 차액 합계(원)"]) + "원"]],
          [4.35] * 4, num_cols=(0, 1, 2, 3))

    heading(doc, "3. 청구·입금 차액 프로젝트")
    if diff_rows:
        shown = diff_rows[:MAX_DIFF_ROWS]
        table(doc, ["프로젝트ID", "프로젝트명", "담당부서", "청구합계(원)", "입금합계(원)", "차액(원)"],
              [[r["프로젝트ID"], r["프로젝트명"], r["담당부서"], won(r["청구금액합계(원)"]),
                won(r["입금금액합계(원)"]), won(r["청구-입금차액(원)"])] for r in shown],
              [2.0, 4.0, 2.2, 3.0, 3.0, 3.2], num_cols=(3, 4, 5))
        if len(diff_rows) > len(shown):
            para(doc, f"외 {len(diff_rows) - len(shown)}건은 결과표 '정산검증' 시트 참조.", size=8.5, color="595959")
        para(doc, "차액 = 청구합계 − 입금합계. 숫자 차이만 표시하며 미수·연체 여부를 뜻하지 않습니다.",
             size=8, color="595959", before=1)
    else:
        para(doc, "해당 없음.")

    heading(doc, "4. 오류 및 확인 필요 항목")
    issues = d["오류"] + d["확인필요"]
    if issues:
        shown = issues[:MAX_ISSUE_ROWS]
        table(doc, ["구분", "대상", "항목", "내용"],
              [[r["구분"], (r["프로젝트ID"] or "") + (f" ({r['시트']} {r['행']}행)" if r["행"] not in (None, "") else ""),
                r["항목"], r["내용"]] for r in shown],
              [1.8, 4.2, 3.4, 8.0])
        if len(issues) > len(shown):
            para(doc, f"외 {len(issues) - len(shown)}건은 결과표 '오류'·'확인필요' 시트 참조.", size=8.5, color="595959")
    else:
        para(doc, "해당 없음.")

    heading(doc, "5. 담당자 검토사항")
    for line in reviews[:MAX_REVIEW_LINES]:
        para(doc, "□ " + line, size=9)
    if len(reviews) > MAX_REVIEW_LINES:
        para(doc, f"□ 외 {len(reviews) - MAX_REVIEW_LINES}건은 결과표 참조.", size=9)

    heading(doc, "6. 미검증 범위")
    unv = ", ".join(r["항목"] for r in d["미검증항목"] if r.get("상태") == "미검증")
    para(doc, f"{unv}. 이 보고서는 검증 결과표의 숫자만 옮겼으며 원본 거래자료를 다시 계산하지 않았습니다.", size=9)
    return doc


# ---------------------------------------------------------------- 7-2. 작성 후 본문 숫자 대조
def doc_text(doc):
    parts = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:
            for c in row.cells:
                parts.append(c.text)
    return "\n".join(parts)


def number_check(text, allowed, derived):
    """보고서의 금액(콤마 숫자)과 'N건' 숫자가 결과표 또는 표시용 파생 건수에 있는지 확인."""
    bad = []
    for m in re.findall(r"\d{1,3}(?:,\d{3})+", text):
        if int(m.replace(",", "")) not in allowed:
            bad.append(m)
    for m in re.findall(r"(\d+)\s*건", text):
        if int(m) not in allowed | derived:
            bad.append(m + "건")
    return bad


def page_count(docx_path):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        return None
    with tempfile.TemporaryDirectory() as td:
        try:
            subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", td, docx_path],
                           capture_output=True, timeout=120)
        except Exception:
            return None
        pdfs = [f for f in os.listdir(td) if f.endswith(".pdf")]
        if not pdfs:
            return None
        data = open(os.path.join(td, pdfs[0]), "rb").read()
        return len(re.findall(rb"/Type\s*/Page[^s]", data)) or None


def main():
    ap = argparse.ArgumentParser(description="정산검증 결과표 → 부서장용 1페이지 보고서")
    ap.add_argument("--input", required=True, help="data-validator가 만든 정산검증_결과표.xlsx")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--out-name", default="정산검증_부서장보고서.docx")
    ap.add_argument("--overwrite", action="store_true")
    a = ap.parse_args()

    if not os.path.isfile(a.input):
        sys.exit(f"입력 파일 없음: {a.input}")
    d, problems = load(a.input)
    if problems:
        print(json.dumps(dict(saved=False, reason="결과표 구조가 data-validator 형식이 아님", problems=problems),
                         ensure_ascii=False, indent=2))
        sys.exit(2)

    checks, diff_rows = consistency(d)
    if any(c["결과"] != "일치" for c in checks):
        print(json.dumps(dict(saved=False, reason="결과표 내부 수치 불일치 → 보고서 작성 중단", checks=checks),
                         ensure_ascii=False, indent=2, default=str))
        sys.exit(3)

    reviews = review_items(diff_rows, d)
    doc = build_doc(d, diff_rows, reviews, os.path.basename(a.input))

    issues_n = len(d["오류"]) + len(d["확인필요"])
    derived = {len(diff_rows), max(len(diff_rows) - MAX_DIFF_ROWS, 0),
               max(issues_n - MAX_ISSUE_ROWS, 0), max(len(reviews) - MAX_REVIEW_LINES, 0)}
    bad = number_check(doc_text(doc), d["allowed"], derived)
    if bad:
        print(json.dumps(dict(saved=False, reason="보고서에 결과표에 없는 숫자 포함", numbers=bad),
                         ensure_ascii=False, indent=2))
        sys.exit(4)

    os.makedirs(a.out_dir, exist_ok=True)
    out = os.path.join(a.out_dir, a.out_name)
    if os.path.exists(out) and not a.overwrite:
        stem, ext = os.path.splitext(a.out_name)
        out = os.path.join(a.out_dir, f"{stem}_{dt.datetime.now():%Y%m%d_%H%M%S}{ext}")
    doc.save(out)

    # 저장본 재확인
    reread = Document(out)
    bad2 = number_check(doc_text(reread), d["allowed"], derived)
    pages = page_count(out)
    print(json.dumps(dict(
        saved=os.path.isfile(out), output=out,
        consistency={c["항목"]: c["결과"] for c in checks},
        report_numbers_all_in_source=not bad2, unmatched_numbers=bad2,
        pages=pages if pages is not None else "미검증(변환 도구 없음)",
        one_page=(pages == 1) if pages is not None else "미검증",
        diff_projects=[r["프로젝트ID"] for r in diff_rows],
        errors=len(d["오류"]), checks=len(d["확인필요"])), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
